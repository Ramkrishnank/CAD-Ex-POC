#include "D:/Ramk/CAD R&D/opencascade-7.3.0/src/AppDef/AppDef_ResConstraintOfTheGradient.hxx"
